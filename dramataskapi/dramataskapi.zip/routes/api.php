<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

Route::group([
    'middleware' => 'api'
], function ($router) {
    // Rutas de autenticación
    Route::post('auth/registro', [AuthController::class, 'registro']);
    Route::post('auth/login', [AuthController::class, 'login']);

    // Rutas protegidas
    Route::group(['middleware' => ['auth:api']], function () {
        Route::post('auth/logout', [AuthController::class, 'logout']);
        Route::post('auth/refresh', [AuthController::class, 'refresh']);
        Route::get('auth/perfil', [AuthController::class, 'perfil']);
    });
});

// Ruta de prueba
Route::get('test', function () {
    return response()->json([
        'mensaje' => 'API funcionando correctamente',
        'estado' => 'activo',
        'timestamp' => now()->toIso8601String(),
        'version' => '1.0.0'
    ]);
});
